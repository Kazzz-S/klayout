#-------------------------------------------------------------------------
# File: Homebrew-HUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-H.zip
#
# "-H" implies "Heavy weight", "Hybrid", and "Heterogeneous".
#
# Last modified: 2025-11-10
#-------------------------------------------------------------------------

This folder contains the "KLayoutHomebrew-H.app" script bundle and some sample icon files.

[1] MacPorts and Homebrew setup
    Unlike the sibling DMGs like "LW-klayout-0.30.4-macOS-Sequoia-1-qt6Brew-Rhb34Phb313.dmg,"
    this package contains the Qt5 from MacPorts and Python 3.11.x frameworks from Homebrew.
    Therefore, you don't need to install the MacPorts and Homebrew development environments.
    The Ruby framework is the OS-bundled one. Hence, this is a "hybrid" system.

    You can use the built-in 'pip' tool to install different Python packages as below.
    Here, let's install 'pandas', 'scipy', and 'matplotlib', for example.
      1) Start the Terminal

      2) $ cd /Applications/klayout.app/Contents/MacOS

      3) $ ./start-console.py   <=== this will invoke the built-in Python
        Python 3.11.14 (main, Oct  9 2025, 16:16:55) [Clang 16.0.0 (clang-1600.0.26.6)] on darwin
        Type "help", "copyright", "credits" or "license" for more information.
        (KLayout Python Console)
        >>> howtopip()

        --------------------------------------------------------------------------------
        (1) Install ['pandas', 'scipy', 'matplotlib']
        >>> import pip
        >>> pip.main( ['install', 'pandas', 'scipy', 'matplotlib'] + piptarget )

        (2) List modules
        >>> import pip
        >>> pip.main( ['list'] )

        (3) Uninstall ['scipy']
        >>> import pip

        >>> pip.main( ['uninstall', 'scipy'] )
        --------------------------------------------------------------------------------

        >>> import pip
        >>> pip.main( ['install', 'pandas', 'scipy', 'matplotlib'] + piptarget )
        WARNING: pip is being invoked by an old script wrapper. This will fail in a future version of pip.
        Please see https://github.com/pypa/pip/issues/5599 for advice on fixing the underlying issue.
        To avoid this problem you can invoke Python with '-m pip' instead of running pip directly.
        Collecting pandas
          Downloading pandas-2.3.3-cp311-cp311-macosx_10_9_x86_64.whl.metadata (91 kB)
        Collecting scipy
          Downloading scipy-1.16.3-cp311-cp311-macosx_14_0_x86_64.whl.metadata (62 kB)
        Collecting matplotlib
          Downloading matplotlib-3.10.7-cp311-cp311-macosx_10_12_x86_64.whl.metadata (11 kB)
        Collecting numpy>=1.23.2 (from pandas)
          Downloading numpy-2.3.4-cp311-cp311-macosx_14_0_x86_64.whl.metadata (62 kB)
        Collecting python-dateutil>=2.8.2 (from pandas)
          Using cached python_dateutil-2.9.0.post0-py2.py3-none-any.whl.metadata (8.4 kB)
        Collecting pytz>=2020.1 (from pandas)
          Using cached pytz-2025.2-py2.py3-none-any.whl.metadata (22 kB)
        Collecting tzdata>=2022.7 (from pandas)
          Using cached tzdata-2025.2-py2.py3-none-any.whl.metadata (1.4 kB)
        Collecting contourpy>=1.0.1 (from matplotlib)
          Using cached contourpy-1.3.3-cp311-cp311-macosx_10_9_x86_64.whl.metadata (5.5 kB)
        Collecting cycler>=0.10 (from matplotlib)
          Using cached cycler-0.12.1-py3-none-any.whl.metadata (3.8 kB)
        Collecting fonttools>=4.22.0 (from matplotlib)
          Downloading fonttools-4.60.1-cp311-cp311-macosx_10_9_x86_64.whl.metadata (112 kB)
        Collecting kiwisolver>=1.3.1 (from matplotlib)
          Using cached kiwisolver-1.4.9-cp311-cp311-macosx_10_9_x86_64.whl.metadata (6.3 kB)
        Collecting packaging>=20.0 (from matplotlib)
          Using cached packaging-25.0-py3-none-any.whl.metadata (3.3 kB)
        Collecting pillow>=8 (from matplotlib)
          Downloading pillow-12.0.0-cp311-cp311-macosx_10_10_x86_64.whl.metadata (8.8 kB)
        Collecting pyparsing>=3 (from matplotlib)
          Using cached pyparsing-3.2.5-py3-none-any.whl.metadata (5.0 kB)
        Collecting six>=1.5 (from python-dateutil>=2.8.2->pandas)
          Using cached six-1.17.0-py2.py3-none-any.whl.metadata (1.7 kB)
        Downloading pandas-2.3.3-cp311-cp311-macosx_10_9_x86_64.whl (11.6 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 11.6/11.6 MB 8.9 MB/s  0:00:01
        Downloading scipy-1.16.3-cp311-cp311-macosx_14_0_x86_64.whl (23.5 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 23.5/23.5 MB 8.6 MB/s  0:00:02
        Downloading numpy-2.3.4-cp311-cp311-macosx_14_0_x86_64.whl (6.9 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 6.9/6.9 MB 8.4 MB/s  0:00:00
        Downloading matplotlib-3.10.7-cp311-cp311-macosx_10_12_x86_64.whl (8.3 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 8.3/8.3 MB 8.7 MB/s  0:00:00
        Using cached contourpy-1.3.3-cp311-cp311-macosx_10_9_x86_64.whl (288 kB)
        Using cached cycler-0.12.1-py3-none-any.whl (8.3 kB)
        Downloading fonttools-4.60.1-cp311-cp311-macosx_10_9_x86_64.whl (2.4 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 2.4/2.4 MB 8.2 MB/s  0:00:00
        Using cached kiwisolver-1.4.9-cp311-cp311-macosx_10_9_x86_64.whl (66 kB)
        Using cached packaging-25.0-py3-none-any.whl (66 kB)
        Downloading pillow-12.0.0-cp311-cp311-macosx_10_10_x86_64.whl (5.3 MB)
           ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ 5.3/5.3 MB 9.2 MB/s  0:00:00
        Using cached pyparsing-3.2.5-py3-none-any.whl (113 kB)
        Using cached python_dateutil-2.9.0.post0-py2.py3-none-any.whl (229 kB)
        Using cached pytz-2025.2-py2.py3-none-any.whl (509 kB)
        Using cached six-1.17.0-py2.py3-none-any.whl (11 kB)
        Using cached tzdata-2025.2-py2.py3-none-any.whl (347 kB)
        Installing collected packages: pytz, tzdata, six, pyparsing, pillow, packaging, numpy, \
        kiwisolver, fonttools, cycler, scipy, python-dateutil, contourpy, pandas, matplotlib
        Successfully installed contourpy-1.3.3 cycler-0.12.1 fonttools-4.60.1 kiwisolver-1.4.9 \
        matplotlib-3.10.7 numpy-2.3.4 packaging-25.0 pandas-2.3.3 pillow-12.0.0 pyparsing-3.2.5 \
        python-dateutil-2.9.0.post0 pytz-2025.2 scipy-1.16.3 six-1.17.0 tzdata-2025.2
        0

        >>> quit()


[2] KLayoutHomebrew-H.app
    Optionally, drag and drop this bundle to the /Applications directory, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script sets the LANG environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutHomebrew-H.app.Bash
    This file is the source Bash script of the "KLayoutHomebrew-H.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutHomebrew-H.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."


[5] Using the git-based Salt Package Manager through a proxy server
    If you use the git-based Salt Package Manager through a proxy server, you need to set
    the 'KLAYOUT_GIT_HTTP_PROXY' environment variable. For example,
    ```
      $ export KLAYOUT_GIT_HTTP_PROXY="http://111.222.333.444:5678"
    ```
    Ask your system administrator for the actual IP address and port number of your proxy server.

    Downloading data from the package server might time out (default is 10 sec).
    If so, set the 'KLAYOUT_HTTP_TIMEOUT' environment variable.
    For example, to make a timeout of 20 seconds,
    ```
      $ export KLAYOUT_HTTP_TIMEOUT=20
    ```

[EOF]

#-------------------------------------------------------------------------
# File: Homebrew-HUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-H.zip
#
# "-H" implies "Heavy weight" and "Hybrid"
#
# Last modified: 2023-01-02
#-------------------------------------------------------------------------

This folder contains the "KLayoutHomebrew-H.app" script bundle and some sample icon files.


[1] Homebrew setup
    Unlike the sibling DMGs like "LW-klayout-0.28.2-macOS-Monterey-2-qt5Brew-Rhb31Phb39.dmg,"
    this package contains the Qt5 and Python frameworks from Homebrew.
    Therefore, you don't need to install the Homebrew development environment.
    The Ruby framework is the OS-bundled one. Hence, this is a "hybrid" system.

    You can use the built-in 'pip' tool to install different Python packages as below.
    Here, let's install 'pandas', 'scipy', and 'matplotlib', for example.
      1) Start the Terminal

      2) $ cd /Applications/klayout.app/Contents/MacOS

      3) $ ./start-console.py   <=== this will invoke the built-in Python

         Python 3.9.16 (main, Dec  7 2022, 10:15:43)   <=== Python version may differ
         [Clang 14.0.0 (clang-1400.0.29.202)] on darwin
         Type "help", "copyright", "credits" or "license" for more information.
         (KLayout Python Console)

         >>> import pip

         >>> pip.main( ['install', 'pandas', 'scipy', 'matplotlib'] )

         WARNING: pip is being invoked by an old script wrapper. This will fail in a future version of pip.
         Please see https://github.com/pypa/pip/issues/5599 for advice on fixing the underlying issue.
         To avoid this problem you can invoke Python with '-m pip' instead of running pip directly.
         Collecting pandas
           Using cached pandas-1.5.2-cp39-cp39-macosx_10_9_x86_64.whl (12.1 MB)
         Collecting scipy
           Using cached scipy-1.9.3-cp39-cp39-macosx_10_9_x86_64.whl (34.3 MB)
         Collecting matplotlib
           Using cached matplotlib-3.6.2-cp39-cp39-macosx_10_12_x86_64.whl (7.3 MB)
         Collecting numpy>=1.20.3
           Using cached numpy-1.24.1-cp39-cp39-macosx_10_9_x86_64.whl (19.8 MB)
         :
         :
         Successfully installed contourpy-1.0.6 cycler-0.11.0 fonttools-4.38.0 kiwisolver-1.4.4 \
                      matplotlib-3.6.2 numpy-1.24.1 packaging-22.0 pandas-1.5.2 pillow-9.3.0 \
                      pyparsing-3.0.9 python-dateutil-2.8.2 pytz-2022.7 scipy-1.9.3 six-1.16.0
         0

         >>> quit()

[2] KLayoutHomebrew-H.app
    Optionally, drag and drop this bundle to the /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script sets the LANG environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutHomebrew-H.app.Bash
    This file is the source Bash script of the "KLayoutHomebrew-H.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutHomebrew-H.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."

[EOF]

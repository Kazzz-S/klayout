#-------------------------------------------------------------------------
# File: Anaconda3User-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-A.zip
#
# Last modified: 2021-11-07
#-------------------------------------------------------------------------

This folder contains the "KLayoutAna3.app" script bundle and some sample icon files.


[1] Anaconda3 setup
    First of all, to use this package, you need to set up the Anaconda3 environment.
    The author has installed 'Anaconda3-2020.07-MacOSX-x86_64.pkg' with Python 3.8.
    If you have installed Anaconda3 under $HOME/opt/anaconda3/, which is the default,
    make a symbolic link:
        /Applications/anaconda3/ ---> $HOME/opt/anaconda3/

    Next, at least, you have to install the Ruby package (Qt5 and Python3 are installed from the beginning):
        % conda install ruby

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    You can add different Python modules such as numpy, scipy, pandas, and so on by the
    "conda install" command, too.


[2] KLayoutAna3.app
    This bundle is for those who have the Anaconda3 environment under /Applications/anaconda3.
    Optionally, drag and drop this bundle to /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The standard installation deploys the Anaconda3 under $HOME/opt/anaconda3/.
    Therefore you need to make a symbolic link: /Applications/anaconda3 ---> $HOME/opt/anaconda3/
    The built-in Bash script sets and exports "PYTHONHOME" environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.
    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.

    If you wish to make this package coexist with the standard one (Qt5 Frameworks embedded)
    that uses the OS-bundled Ruby and Python (2.7.x),
      1) Rename "/Applications/klayout.app" to "/Applications/klayout-ana3.app"
      2) Edit this script using "Automator.app"
              # myklayout=/Applications/klayout.app (comment out)
              # myconfig=$HOME/.klayout/klayoutrc (comment out)
                |
                |
                V
              myklayout=/Applications/klayout-ana3.app
              myconfig=$HOME/.klayout/klayoutrc-ana3


[3] KLayoutAna3.app.Bash
    This is the source Bash script of the "KLayoutAna3.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your own script bundle
    from scratch. See "KLayoutAna3.app.png" image file.

[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click the script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, then it is highlighted.
      3) Drag and drop any icon onto the "robot icon."

[EOF]

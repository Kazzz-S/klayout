#-------------------------------------------------------------------------
# File: Anaconda3User-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-A.zip
#
# Last modified: 2023-11-11
#-------------------------------------------------------------------------

This folder contains the "KLayoutAna3.app" script bundle and some sample icon files.


[1] Anaconda3 setup
    First, you must set up the Anaconda3 environment to use this package.
    The author initially installed 'Anaconda3-2023.09-0-MacOSX-x86_64.pkg' and then maintained
    the packages with the 'conda' command to finally have the three core packages,
    Qt, Python, Ruby, and libgit2 as shown below.
            qt-main     5.15.2  hf83fbd5_10
            python      3.11.5  hf27a42d_0
            ruby        3.1.4   h6572bd2_0
            libgit2     1.7.1   h94d3247_0
    Qt and Python are installed by default. The other two packages are installed with:
    ```
      $ conda install ruby=3.1.4
      $ conda install -c conda-forge libgit2
    ```

    If you have installed Anaconda3 under $HOME/opt/anaconda3/, which is the default,
    make a symbolic link:
        /Applications/anaconda3/ ---> $HOME/opt/anaconda3/

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    You can add different Python modules such as numpy, scipy, pandas, and so on by the
    "conda install" command, too.


[2] KLayoutAna3.app
    This bundle is for those with the Anaconda3 environment under /Applications/anaconda3.
    Optionally, drag and drop this bundle to the /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The standard installation deploys the Anaconda3 under $HOME/opt/anaconda3/.
    Therefore you need to make a symbolic link: /Applications/anaconda3 ---> $HOME/opt/anaconda3/

    The built-in Bash script sets the LANG environment variable, exports the "PYTHONHOME"
    environment variable, then invokes "/Applications/klayout.app" in the EDITOR mode.

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutAna3.app.Bash
    This file is the source Bash script of the "KLayoutAna3.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutAna3.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."


[5] KLayout Python Module
    This LW*.dmg contains the KLayout Python Module (pymod) compliant with the base Python system.
    Refer to "pymod-pip3-ana3.txt" for more details.
    You can either install the pymod from the official PyPI website at any time:
      https://pypi.org/project/klayout/.

[EOF]

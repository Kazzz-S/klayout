#-------------------------------------------------------------------------
# File: MacPortsUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-P.zip
#
# Last modified: 2023-10-25
#-------------------------------------------------------------------------

This folder contains the "KLayoutPorts.app" script bundle and some sample icon files.


[1] MacPorts setup
    First, you must set up the MacPorts environment to use this package.
    Referring to https://www.macports.org/install.php, follow the three steps for Quickstart.
      1. Install Xcode and the Xcode Command Line Tools
      2. Agree to Xcode license in Terminal: sudo xcodebuild -license
      3. Install MacPorts for your version of the Mac operating system:
              o macOS Sonoma v14
              o macOS Ventura v13
              o macOS Monterey v12
              o macOS Big Sur v11
              o Older OS? See here.

    Next, install some ports. qt5, ruby32, and python311 are mandatory.
        % sudo port install coreutils
        % sudo port install findutils
        % sudo port install qt5
        % sudo port install ruby32
        % sudo port install python311
        % sudo port install py311-pip

        % sudo port select --set python3 python311
        % sudo port select --set python  python311
        % sudo port select --set pip3    pip311
        % sudo port select --set pip     pip311

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    The attached file "MacPortsPythonPip.txt" has captured the steps I followed to add some
    Python modules using the "pip-3.11 (aka pip3)" command on Monterey.
    Please note that the module versions may not be up-to-date.


[2] KLayoutPorts.app
    This bundle is for those with the MacPorts environment under /opt/local.
    Optionally, drag and drop this bundle to the /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script sets the LANG environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutPorts.app.Bash
    This file is the source Bash script of the "KLayoutPorts.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutPorts.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."


[5] KLayout Python Module
    This LW*.dmg contains the KLayout Python Module (pymod) compliant with the base Python system.
    Refer to "pymod-pip3-mp311.txt" for more details.

[EOF]

#-------------------------------------------------------------------------
# File: HomebrewUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-B.zip
#
# Last modified: 2023-12-10
#-------------------------------------------------------------------------

This folder contains the "KLayoutHomebrew.app" script bundle and some sample icon files.


[1] Homebrew setup
    First, you must set up the Homebrew environment to use this package.
    Install the **Intel Version Homebrew** to its default location (/usr/local for macOS Intel;
    cf. /opt/homebrew for Apple Silicon).
       Ref. https://github.com/Homebrew/brew/blob/master/docs/Installation.md#alternative-installs.

    If you are using an Apple Silicon machine, according to a piece of web information,
    specify the architecture name like:
        % arch -x86_64  /bin/bash -c \
           "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"

    At least you have to install Qt5 (version 5.x), Ruby (version 3.2.x),
    Python (version 3.11.x) and libgit2 (version 1.6.x) packages:
        $ brew install qt@5
        $ brew install ruby@3.2
        $ brew install python@3.11
        $ brew install libgit2

    The main reason you chose this package would be to use KLayout's PYA in Python 3.x.
    The attached file "HomebrewPythonPip.txt" has captured the steps I followed to add some
    Python modules using the "pip" command on Catalina.
    Please note that the module versions may not be up-to-date.


[2] KLayoutHomebrew.app
    This bundle is for those with the Homebrew environment under /usr/local/opt/ (for macOS Intel)
    or /opt/homebrew/opt/ (for Apple Silicon).
    Optionally, drag and drop this bundle to the /Applications folder, too.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script sets the LANG environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutHomebrew.app.Bash
    This file is the source Bash script of the "KLayoutHomebrew.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutHomebrew-B.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."


[5] KLayout Python Module
    This LW*.dmg contains the KLayout Python Module (pymod) compliant with the base Python system.
    Refer to "pymod-pip3-hb39.txt" for more details.
    You can either install the pymod from the official PyPI website at any time:
      https://pypi.org/project/klayout/.


[6] Using the git-based Salt Package Manager through a proxy server
    If you use the git-based Salt Package Manager through a proxy server, you need to set
    the 'KLAYOUT_GIT_HTTP_PROXY' environment variable. For example,
    ```
      $ export KLAYOUT_GIT_HTTP_PROXY="http://111.222.333.444:5678"
    ```
    Ask your system administrator for the actual IP address and port number of your proxy server.

[EOF]

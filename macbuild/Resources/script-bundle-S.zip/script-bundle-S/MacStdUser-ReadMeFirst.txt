#-------------------------------------------------------------------------
# File: MacStdUser-ReadMeFirst.txt
#                              in macbuild/Resources/script-bundle-S.zip
#
# Last modified: 2024-03-18
#-------------------------------------------------------------------------

This folder contains the "KLayoutStd.app" script bundle and some sample icon files.


[1] Python3 setup
    First, you must confirm that you have the OS-standard Python3 installed.
    The path to the executable is:
      /usr/bin/python3

    Check the version by, for example,
      $ cd /usr/bin/
      $ ./python3 --version
        Python 3.9.6

    If Python3 is not yet ready, you will be prompted to install the command line developer tools.
    See <command-line-tools-1.png> and <command-line-tools-2.png>.
    ```
      xcode-select: note: No developer tools were found, requesting install.
      If developer tools are located at a non-default location on disk,
      use `sudo xcode-select --switch path/to/Xcode.app` to specify the Xcode that you wish to use
      for command line developer tools, and cancel the installation dialog.
      See `man xcode-select` for more details.
    ```
    Then, install the command line developer tools to the default location:
                                                   ^^^^^^^^^^^^^^^^^^^^^^^
      /Library/Developer/CommandLineTools/Library/Frameworks/Python3.framework/

    After installation,
    ```
      Monterey1{kazzz-s} ~ (1)% which python3
      /usr/bin/python3

      Monterey1{kazzz-s} ~ (2)% python3 --version
      Python 3.9.6
    ```


[2] KLayoutStd.app
    This bundle provides the startup services.
    Optionally, drag and drop this bundle to the /Applications folder.
    As the bundle consists of a simple Bash script, you may be able to edit it as you like
    with the help of the "Automator.app" tool.

    The built-in Bash script sets the LANG environment variable, then invokes
    "/Applications/klayout.app" in the EDITOR mode.

    You can set the proxy in this script if required. See [6].

    KLayout's configuration file is "$HOME/.klayout/klayoutrc."
    You can invoke multiple instances of KLayout using this script bundle.


[3] KLayoutStd.app.Bash
    This file is the source Bash script of the "KLayoutStd.app" bundle.
    You can refer to this script and use the "Automator.app" tool to create your script bundle
    from scratch. See the "KLayoutStd.app.png" image file.


[4] Application Icons
    You can change the application icon of a script bundle using "Finder."
      1) Right-click script bundle "*.app" and "Get info."
      2) Click the default "robot icon" at the top-left, highlighting it.
      3) Drag and drop any icon onto the "robot icon."


[5] Klayout Standalone Python Package
      This ST*.dmg does not contain the KLayout standalone Python package (klayout*.whl) compliant with the base Python system.
      You can install the package from the official PyPI website at any time:
      https://pypi.org/project/klayout/.


[6] Using the git-based Salt Package Manager through a proxy server
    If you use the git-based Salt Package Manager through a proxy server, you need to set
    the 'KLAYOUT_GIT_HTTP_PROXY' environment variable. For example,
    ```
      $ export KLAYOUT_GIT_HTTP_PROXY="http://111.222.333.444:5678"
    ```
    Ask your system administrator for the actual IP address and port number of your proxy server.

[EOF]
